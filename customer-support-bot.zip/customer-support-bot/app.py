from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import json

app = Flask(__name__)
CORS(app)

# Ollama API endpoint
OLLAMA_API = "http://localhost:11434/api/generate"

@app.route("/", methods=["GET"])
def home():
    return "Customer Support Bot is running! Use POST /chat to send messages."

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"error": "No message provided"}), 400

    payload = {"model": "customer-support", "prompt": user_input}

    try:
        # enable streaming
        response = requests.post(OLLAMA_API, json=payload, stream=True)
        response.raise_for_status()

        full_reply = ""
        for line in response.iter_lines():
            if line:
                try:
                    data = json.loads(line.decode("utf-8"))
                    if "response" in data:
                        full_reply += data["response"]
                except json.JSONDecodeError:
                    continue
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Failed to reach Ollama API", "details": str(e)}), 500

    return jsonify({"reply": full_reply.strip()})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
